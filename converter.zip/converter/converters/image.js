/**
 * 项目名称：TextConverter
 * 功能描述：提供Office转PDF、PDF转图片/文本/指定页、图片转PDF/TXT、TXT转PDF、图片格式转换、OCR识别等功能
 * @author: 择梦舟
 * @copyright: Copyright (c) 2025 择梦舟
 * @license: Apache License 2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

const sharp = require("sharp");
const path = require("path");

async function imageConvert(inputPath, outPath){
  const ext = path.extname(outPath).toLowerCase();
  let img = sharp(inputPath);

  if (ext === ".png") await img.png().toFile(outPath);
  else if (ext === ".jpg" || ext === ".jpeg") await img.jpeg({ quality: 90 }).toFile(outPath);
  else if (ext === ".webp") await img.webp({ quality: 85 }).toFile(outPath);
  else await img.png().toFile(outPath);
}

module.exports = { imageConvert };

/**
 * 项目名称：TextConverter
 * 功能描述：提供Office转PDF、PDF转图片/文本/指定页、图片转PDF/TXT、TXT转PDF、图片格式转换、OCR识别等功能
 * @author: 择梦舟
 * @copyright: Copyright (c) 2025 择梦舟
 * @license: Apache License 2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

const fs = require("fs");
const { PDFDocument, StandardFonts, rgb } = require("pdf-lib");

async function txtToPdf(inputTxt, outPdf){
  const text = fs.readFileSync(inputTxt, "utf8");
  const pdf = await PDFDocument.create();
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const fontSize = 12;
  const margin = 36;

  let page = pdf.addPage();
  let { width, height } = page.getSize();
  let y = height - margin;

  const lines = text.replace(/\r\n/g,"\n").split("\n");
  for (const line of lines){
    if (y < margin){
      page = pdf.addPage();
      ({ width, height } = page.getSize());
      y = height - margin;
    }
    page.drawText(line, { x: margin, y, size: fontSize, font, color: rgb(0,0,0) });
    y -= fontSize * 1.4;
  }

  fs.writeFileSync(outPdf, await pdf.save());
}

module.exports = { txtToPdf };

/**
 * 项目名称：TextConverter
 * 功能描述：提供Office转PDF、PDF转图片/文本/指定页、图片转PDF/TXT、TXT转PDF、图片格式转换、OCR识别等功能
 * @author: 择梦舟
 * @copyright: Copyright (c) 2025 择梦舟
 * @license: Apache License 2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


const fs = require("fs");
const path = require("path");
const { PDFDocument } = require("pdf-lib");
const { execFile } = require("child_process");

function parsePageSpec(spec){
  const s = (spec||"").trim();
  if (!s) return null;
  const out = new Set();
  for (const part of s.split(",").map(x=>x.trim()).filter(Boolean)){
    const m = part.match(/^(\d+)(-(\d+))?$/);
    if(!m) throw new Error("Bad pageSpec");
    const a = parseInt(m[1],10);
    const b = m[3] ? parseInt(m[3],10) : a;
    const start = Math.min(a,b), end = Math.max(a,b);
    for(let i=start;i<=end;i++) out.add(i);
  }
  return Array.from(out).sort((x,y)=>x-y);
}

async function pdfExtractPages(inputPdf, outPdf, pageSpec){
  const pages = parsePageSpec(pageSpec);
  const bytes = fs.readFileSync(inputPdf);
  const src = await PDFDocument.load(bytes);
  const dst = await PDFDocument.create();

  const total = src.getPageCount();
  const pick = pages ? pages : Array.from({length: total}, (_,i)=>i+1);

  for (const p of pick){
    if (p < 1 || p > total) continue;
    const [copied] = await dst.copyPages(src, [p-1]);
    dst.addPage(copied);
  }
  fs.writeFileSync(outPdf, await dst.save());
}

function pdfToImages(inputPdf, outDir, { quality="balanced" } = {}){
  return new Promise((resolve, reject) => {
    const base = path.join(outDir, "page");
    const scale =
      quality === "high" ? ["-r","220"] :
      quality === "small" ? ["-r","110"] :
      ["-r","160"];

    execFile("pdftoppm", [
      ...scale,
      "-png",
      inputPdf,
      base
    ], { timeout: 180000 }, (err, stdout, stderr) => {
      if (err) return reject(new Error(stderr || stdout || err.message));
      const files = fs.readdirSync(outDir)
        .filter(x=>x.startsWith("page-") && x.endsWith(".png"))
        .map(x=>path.join(outDir, x))
        .sort((a,b)=>a.localeCompare(b, undefined, {numeric:true}));
      resolve(files);
    });
  });
}

function pdfToText(inputPdf, outTxt){
  return new Promise((resolve, reject) => {
    execFile("pdftotext", [inputPdf, outTxt], { timeout: 60000 }, (err, stdout, stderr) => {
      if (err) return reject(new Error(stderr || stdout || err.message));
      resolve();
    });
  });
}

async function imagesToPdf(imagePaths, outPdf){
  const pdfDoc = await PDFDocument.create();

  for (const imgPath of imagePaths){
    const bytes = fs.readFileSync(imgPath);
    const ext = path.extname(imgPath).toLowerCase();
    const img = (ext === ".png")
      ? await pdfDoc.embedPng(bytes)
      : await pdfDoc.embedJpg(bytes);

    const page = pdfDoc.addPage([img.width, img.height]);
    page.drawImage(img, { x:0, y:0, width: img.width, height: img.height });
  }

  fs.writeFileSync(outPdf, await pdfDoc.save());
}

module.exports = { pdfExtractPages, pdfToImages, pdfToText, imagesToPdf };

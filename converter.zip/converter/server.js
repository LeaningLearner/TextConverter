/**
 * 项目名称：TextConverter
 * 功能描述：提供Office转PDF、PDF转图片/文本/指定页、图片转PDF/TXT、TXT转PDF、图片格式转换、OCR识别等功能
 * @author: 择梦舟
 * @copyright: Copyright (c) 2025 择梦舟
 * @license: Apache License 2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

const express = require("express");
const cors = require("cors");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const { convertOfficeToPdf } = require("./converters/office");
const { pdfToImages, pdfExtractPages, pdfToText, imagesToPdf } = require("./converters/pdf");
const { imageConvert } = require("./converters/image");
const { txtToPdf } = require("./converters/text");
const { ocrImageToText } = require("./converters/ocr");

const app = express();
app.use(cors());
app.use(express.json());

const UPLOAD_DIR = path.join(__dirname, "uploads");
const OUTPUT_DIR = path.join(__dirname, "outputs");
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
fs.mkdirSync(OUTPUT_DIR, { recursive: true });

const upload = multer({ dest: UPLOAD_DIR });

function extLower(p){ return path.extname(p).toLowerCase(); }
function safeBase(name){ return name.replace(/[^\w.-]+/g, "_").slice(0, 80); }
function nowId(){ return Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8); }

app.post("/api/convert", upload.array("files", 20), async (req, res) => {
  try {
    const { fromFmt="auto", toFmt="pdf", mode="direct", pageSpec="", quality="balanced", merge="false" } = req.body;
    const files = req.files || [];
    if (!files.length) return res.status(400).json({ error: "No files uploaded" });

    // 单文件示例：取第一个文件
    const f = files[0];
    const originalName = f.originalname || "file";
    const inputPath = f.path;
    const inputExt = extLower(originalName);

    const job = nowId();
    const outBase = safeBase(path.parse(originalName).name) + "-" + job;

    let workingPath = inputPath;
    let workingIsPdf = (inputExt === ".pdf");

    const isOffice = [".doc",".docx",".xls",".xlsx",".ppt",".pptx"].includes(inputExt);

    // 指定页：若输入是 Office，则先转 PDF 再抽页
    if (mode === "pages") {
      if (isOffice) {
        await convertOfficeToPdf(workingPath, OUTPUT_DIR);
        const latestPdf = fs.readdirSync(OUTPUT_DIR)
          .filter(x=>x.endsWith(".pdf"))
          .map(x=>({x, t: fs.statSync(path.join(OUTPUT_DIR,x)).mtimeMs}))
          .sort((a,b)=>b.t-a.t)[0];
        if (!latestPdf) return res.status(500).json({ error: "Office->PDF failed: no pdf output found" });
        workingPath = path.join(OUTPUT_DIR, latestPdf.x);
        workingIsPdf = true;
      }

      if (workingIsPdf) {
        const extractedPdf = path.join(OUTPUT_DIR, outBase + ".pages.pdf");
        await pdfExtractPages(workingPath, extractedPdf, pageSpec);
        workingPath = extractedPdf;
        workingIsPdf = true;
      }
    }

    let resultPaths = [];

    if (toFmt === "pdf") {
      if (workingIsPdf) {
        const out = path.join(OUTPUT_DIR, outBase + ".pdf");
        fs.copyFileSync(workingPath, out);
        resultPaths = [out];
      } else if (isOffice) {
        await convertOfficeToPdf(inputPath, OUTPUT_DIR);
        const latestPdf = fs.readdirSync(OUTPUT_DIR)
          .filter(x=>x.endsWith(".pdf"))
          .map(x=>({x, t: fs.statSync(path.join(OUTPUT_DIR,x)).mtimeMs}))
          .sort((a,b)=>b.t-a.t)[0];
        if (!latestPdf) return res.status(500).json({ error: "Office->PDF failed: no pdf output found" });
        resultPaths = [path.join(OUTPUT_DIR, latestPdf.x)];
      } else if ([".png",".jpg",".jpeg",".webp",".bmp",".tif",".tiff"].includes(inputExt)) {
        const out = path.join(OUTPUT_DIR, outBase + ".pdf");
        await imagesToPdf([inputPath], out);
        resultPaths = [out];
      } else if (inputExt === ".txt") {
        const out = path.join(OUTPUT_DIR, outBase + ".pdf");
        await txtToPdf(inputPath, out);
        resultPaths = [out];
      } else {
        return res.status(400).json({ error: "Unsupported input for PDF" });
      }
    } else if (toFmt === "image") {
      if (!workingIsPdf && isOffice) {
        await convertOfficeToPdf(inputPath, OUTPUT_DIR);
        const latestPdf = fs.readdirSync(OUTPUT_DIR)
          .filter(x=>x.endsWith(".pdf"))
          .map(x=>({x, t: fs.statSync(path.join(OUTPUT_DIR,x)).mtimeMs}))
          .sort((a,b)=>b.t-a.t)[0];
        if (!latestPdf) return res.status(500).json({ error: "Office->PDF failed: no pdf output found" });
        workingPath = path.join(OUTPUT_DIR, latestPdf.x);
        workingIsPdf = true;
      }

      if (workingIsPdf) {
        const outDir = path.join(OUTPUT_DIR, outBase + "-imgs");
        fs.mkdirSync(outDir, { recursive: true });
        resultPaths = await pdfToImages(workingPath, outDir, { quality });
      } else if ([".png",".jpg",".jpeg",".webp",".bmp",".tif",".tiff"].includes(inputExt)) {
        const out = path.join(OUTPUT_DIR, outBase + ".png");
        await imageConvert(inputPath, out);
        resultPaths = [out];
      } else {
        return res.status(400).json({ error: "Unsupported input for image" });
      }
    } else if (toFmt === "txt") {
      if (workingIsPdf) {
        const out = path.join(OUTPUT_DIR, outBase + ".txt");
        await pdfToText(workingPath, out);
        resultPaths = [out];
      } else if ([".png",".jpg",".jpeg",".webp",".bmp",".tif",".tiff"].includes(inputExt)) {
        const out = path.join(OUTPUT_DIR, outBase + ".txt");
        await ocrImageToText(inputPath, out);
        resultPaths = [out];
      } else if (inputExt === ".txt") {
        const out = path.join(OUTPUT_DIR, outBase + ".txt");
        fs.copyFileSync(inputPath, out);
        resultPaths = [out];
      } else {
        return res.status(400).json({ error: "Unsupported input for txt" });
      }
    } else {
      return res.status(400).json({ error: "This bundle focuses on PDF/image/txt outputs. Office reverse conversion needs extra tools." });
    }

    const downloadUrls = resultPaths.map(p => "/download/" + path.basename(p));
    return res.json({
      ok: true,
      job,
      outputs: downloadUrls,
      note: "若输出为多张图片，将返回多个链接（建议打包ZIP/前端列表展示）。"
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: String(e.message || e) });
  }
});

app.use("/download", express.static(OUTPUT_DIR));

app.listen(3000, () => console.log("Converter API running: http://localhost:3000"));
